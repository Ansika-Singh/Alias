import React, { useState, useEffect } from 'react';
import { 
  GraduationCap, 
  Calendar, 
  TrendingUp, 
  Award, 
  AlertCircle, 
  Clock, 
  CheckCircle2, 
  Flame, 
  HelpCircle,
  ChevronRight,
  BookOpen,
  FileText,
  MessageSquare,
  Trophy,
  Languages,
  Download,
  CalendarDays,
  ListTodo,
  FlaskConical,
  Megaphone,
  Users,
  BookMarked,
  CreditCard,
  User,
  Badge,
  Home,
  Upload,
  Settings,
  Search,
  MoreVertical,
  CheckCircle,
  XCircle,
  Paperclip,
  ExternalLink,
  ShieldCheck,
  Mail,
  Phone
} from 'lucide-react';
import './StudentPortal.css';
import HeatmapCalendar from '../components/HeatmapCalendar';
import CampusCalendar from '../components/CampusCalendar';
import { apiFetch, get, post } from '../utils/api';
import { useTranslation } from 'react-i18next';

const StudentPortal = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [heatmapData, setHeatmapData] = useState([]);
  const [showDisputeModal, setShowDisputeModal] = useState(false);
  const [selectedCourse, setSelectedCourse] = useState(null);
  const [facultySearch, setFacultySearch] = useState('');
  const { i18n, t } = useTranslation();
  
  const [disputeForm, setDisputeForm] = useState({
    type: 'attendance',
    date: '',
    subject: '',
    reason: ''
  });

  const usn = localStorage.getItem('userEmail') || '1XX19CS001';

  // Sample Portal Data
  const portalData = {
    exams: [
      { id: 1, subject: 'Distributed Systems', date: '2026-05-20', time: '10:00 AM', room: 'LH-301', status: 'Upcoming' },
      { id: 2, subject: 'Machine Learning', date: '2026-05-22', time: '02:00 PM', room: 'LH-102', status: 'Upcoming' },
      { id: 3, subject: 'Software Engineering', date: '2026-05-25', time: '10:00 AM', room: 'Lab-4', status: 'Upcoming' },
      { id: 4, subject: 'Digital Image Processing', date: '2026-05-28', time: '10:00 AM', room: 'LH-205', status: 'Upcoming' },
    ],
    results: [
      { subject: 'Operating Systems', grade: 'A+', marks: '92/100', semester: '5', gpa: '9.5' },
      { subject: 'Computer Networks', grade: 'A', marks: '88/100', semester: '5', gpa: '9.0' },
      { subject: 'Database Management', grade: 'O', marks: '95/100', semester: '5', gpa: '10.0' },
      { subject: 'Theory of Computation', grade: 'B+', marks: '78/100', semester: '5', gpa: '8.0' },
      { subject: 'Microprocessors', grade: 'A', marks: '85/100', semester: '4', gpa: '9.0' },
    ],
    assignments: [
      { id: 1, title: 'MapReduce Implementation', course: 'CS501', due: '2026-05-18', status: 'Pending', priority: 'High' },
      { id: 2, title: 'Neural Network Project Report', course: 'CS502', due: '2026-05-21', status: 'Submitted', priority: 'Medium' },
      { id: 3, title: 'Software Design Patterns Quiz', course: 'CS503', due: '2026-05-19', status: 'Pending', priority: 'Low' },
      { id: 4, title: 'Distributed Hashing Lab', course: 'CS501', due: '2026-05-24', status: 'Pending', priority: 'Medium' },
      { id: 5, title: 'Agile Methodology Case Study', course: 'CS503', due: '2026-05-12', status: 'Submitted', priority: 'High' },
    ],
    projects: [
      { id: 1, name: 'Smart Attendance System', phase: 'Development', progress: 65, team: 'Solo' },
      { id: 2, name: 'E-Commerce Platform', phase: 'Testing', progress: 90, team: 'Group 4' },
      { id: 3, name: 'Real-time Chat App', phase: 'Planning', progress: 15, team: 'Group 2' },
    ],
    labs: [
      { id: 1, name: 'Computer Networks Lab', day: 'Tuesday', reports: 10, pending: 2 },
      { id: 2, name: 'Machine Learning Lab', day: 'Friday', reports: 8, pending: 0 },
      { id: 3, name: 'Distributed Systems Lab', day: 'Monday', reports: 5, pending: 3 },
    ],
    announcements: [
      { id: 1, title: 'End Semester Exam Schedule Out', date: '2026-05-15', category: 'Exam', priority: 'Critical' },
      { id: 2, title: 'Guest Lecture on Quantum Computing', date: '2026-05-17', category: 'Event', priority: 'Normal' },
      { id: 3, title: 'Hostel Outing Permitted for Sunday', date: '2026-05-14', category: 'Admin', priority: 'Low' },
      { id: 4, title: 'Placement Drive: Google Inc.', date: '2026-05-18', category: 'Placement', priority: 'Critical' },
      { id: 5, title: 'Inter-College Hackathon Registration', date: '2026-05-10', category: 'Event', priority: 'Normal' },
    ],
    faculty: [
      { name: 'Dr. Sarah Wilson', dept: 'CSE', role: 'Associate Prof.', email: 'sarah.w@college.edu', image: 'SW' },
      { name: 'Prof. James Chen', dept: 'CSE', role: 'Head of Dept.', email: 'james.c@college.edu', image: 'JC' },
      { name: 'Dr. Elena Rodriguez', dept: 'ISE', role: 'Asst. Prof.', email: 'elena.r@college.edu', image: 'ER' },
      { name: 'Dr. Michael Brown', dept: 'CSE', role: 'Professor', email: 'michael.b@college.edu', image: 'MB' },
      { name: 'Ms. Emily Davis', dept: 'Mathematics', role: 'Lecturer', email: 'emily.d@college.edu', image: 'ED' },
    ],
    events: [
      { date: '2026-05-18', title: 'Tech Symposium', type: 'event' },
      { date: '2026-05-21', title: 'Cultural Fest', type: 'event' },
      { date: '2026-05-24', title: 'Sunday', type: 'holiday' },
      { date: '2026-05-26', title: 'Buddha Purnima', type: 'festival' },
      { date: '2026-05-31', title: 'Sunday', type: 'holiday' },
      { date: '2026-05-10', title: 'Mother\'s Day', type: 'event' },
      { date: '2026-05-01', title: 'Labor Day', type: 'holiday' },
    ],
    library: {
      cardNo: 'LIB-2026-0992',
      booksBorrowed: [
        { title: 'Distributed Systems: Principles', due: '2026-05-25', status: 'Active' },
        { title: 'Clean Code', due: '2026-05-12', status: 'Overdue' },
        { title: 'Introduction to Algorithms', due: '2026-06-01', status: 'Active' },
      ],
      fine: 45.00
    },
    fees: {
      total: 125000,
      paid: 100000,
      due: 25000,
      history: [
        { id: 'TXN_9912', amount: 50000, date: '2025-08-10', status: 'Success' },
        { id: 'TXN_8821', amount: 50000, date: '2026-01-15', status: 'Success' },
        { id: 'TXN_7734', amount: 5000, date: '2026-02-20', status: 'Success' },
      ]
    },
    profile: {
      personal: {
        dob: '2004-05-15',
        phone: '+91 98765 43210',
        email: 'student@college.edu',
        address: '123, Campus Heights, Bangalore'
      },
      family: {
        father: 'Robert Smith',
        mother: 'Jane Smith',
        emergency: '+91 99999 88888'
      },
      documents: [
        { name: '10th Marksheet', type: 'PDF', size: '1.2 MB' },
        { name: '12th Marksheet', type: 'PDF', size: '1.5 MB' },
        { name: 'Entrance Rank Card', type: 'PDF', size: '0.8 MB' },
        { name: 'Profile Photo', type: 'JPG', size: '2.4 MB' },
        { name: 'Aadhar Card', type: 'PDF', size: '0.5 MB' },
      ]
    },
    courses: [
      {
        id: 'CS501',
        name: 'Distributed Systems',
        instructor: 'Dr. Sarah Wilson',
        syllabus: 'Evolution of Distributed Systems, System Models, Interprocess Communication, Remote Invocation, Indirect Communication, Naming, Time & Global States, Coordination, Transactions, Concurrency Control, Distributed File Systems.',
        notes: [
          { title: 'Lec 1: Intro to Distributed Systems', date: '2026-04-10' },
          { title: 'Lec 2: Remote Procedure Call (RPC)', date: '2026-04-15' },
          { title: 'Lec 3: Consistency & Replication', date: '2026-04-22' },
          { title: 'Unit 1 Question Bank', date: '2026-05-01' },
        ]
      },
      {
        id: 'CS502',
        name: 'Machine Learning',
        instructor: 'Prof. James Chen',
        syllabus: 'Introduction to ML, Supervised Learning, Linear Regression, Logistic Regression, Neural Networks, Backpropagation, Support Vector Machines, Unsupervised Learning, K-Means, PCA, Reinforcement Learning Basics.',
        notes: [
          { title: 'Neural Networks - Theory & Practice', date: '2026-04-20' },
          { title: 'SVM Kernel Methods', date: '2026-04-28' },
          { title: 'Mid-Sem Revision Guide', date: '2026-05-05' },
        ]
      },
      {
        id: 'CS503',
        name: 'Software Engineering',
        instructor: 'Dr. Elena Rodriguez',
        syllabus: 'Software Process Models, Agile & Scrum, Requirement Engineering, System Modeling with UML, Architectural Design, Software Testing Strategies, Project Management & Risk Analysis.',
        notes: [
          { title: 'Agile vs Waterfall – Comparison', date: '2026-05-05' },
          { title: 'Design Patterns (GoF 23)', date: '2026-05-12' },
          { title: 'Testing Strategies Cheat Sheet', date: '2026-05-14' },
        ]
      },
      {
        id: 'CS504',
        name: 'Digital Image Processing',
        instructor: 'Dr. Michael Brown',
        syllabus: 'Digital Image Fundamentals, Image Enhancement in Spatial Domain, Filtering in Frequency Domain, Image Restoration, Color Image Processing, Image Compression (JPEG), Morphological Processing.',
        notes: [
          { title: 'Spatial Filters & Convolution', date: '2026-04-18' },
          { title: 'JPEG Compression Steps', date: '2026-04-30' },
        ]
      }
    ]
  };

  useEffect(() => {
    fetchStudentData();
  }, []);

  const mockStudentData = {
    student: { name: 'Ansika Singh', usn: '1XX22CS042', branch: 'CSE', semester: '6' },
    attendance: { percentage: 82, present: 98, total: 120 },
    gamification: { streakCount: 14, points: 1850, badges: ['Perfect Week', 'Early Bird', '30-Day Streak', 'Top Performer'] },
    anomaly: null,
    recent_logs: [
      { date: '2026-05-15', subject: 'Distributed Systems', status: 'Present' },
      { date: '2026-05-15', subject: 'Machine Learning', status: 'Present' },
      { date: '2026-05-14', subject: 'Software Engineering', status: 'Absent' },
      { date: '2026-05-14', subject: 'Digital Image Processing', status: 'Present' },
      { date: '2026-05-13', subject: 'Distributed Systems Lab', status: 'Present' },
    ]
  };

  const fetchStudentData = async () => {
    try {
      const response = await get(`/portal/${usn}/dashboard`);
      const result = await response.json();
      if (result.code === 200) {
        setData(result.data);
      } else {
        setData(mockStudentData);
      }
      
      const heatmapRes = await get(`/analytics/heatmap/${usn}`);
      const heatmapResult = await heatmapRes.json();
      if (heatmapResult.code === 200) {
        setHeatmapData(heatmapResult.data);
      }
    } catch (error) {
      console.error("Error fetching student data, using mock data:", error);
      setData(mockStudentData);
    } finally {
      setLoading(false);
    }
  };

  const handleDisputeSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await post(`/portal/dispute`, { ...disputeForm, usn });
      if (response.ok) {
        alert(`${disputeForm.type === 'attendance' ? 'Dispute' : 'Complaint'} raised successfully!`);
        setShowDisputeModal(false);
      }
    } catch (error) {
      console.error("Error raising dispute/complaint:", error);
    }
  };

  if (loading) return <div className="loading">Loading Portal...</div>;

  const filteredFaculty = portalData.faculty.filter(f => 
    f.name.toLowerCase().includes(facultySearch.toLowerCase()) || 
    f.dept.toLowerCase().includes(facultySearch.toLowerCase())
  );

  return (
    <div className="portal-container">
      <header className="portal-header">
        <div className="user-info">
          <div className="avatar profile-pic">
            <GraduationCap size={32} />
          </div>
          <div>
            <h1>Welcome, {data?.student?.name}</h1>
            <p>{data?.student?.usn} • {data?.student?.branch} • Sem {data?.student?.semester}</p>
          </div>
        </div>
        <div className="stats-quickview">
          <div className="stat-pill">
            <Flame size={18} className="icon-streak" />
            <span>{data?.gamification?.streakCount || 0} Day Streak</span>
          </div>
          <div className="stat-pill">
            <Award size={18} className="icon-points" />
            <span>{data?.gamification?.points || 0} Points</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', background: 'rgba(255,255,255,0.1)', padding: '0.4rem 0.8rem', borderRadius: 'var(--radius-full)' }}>
            <Languages size={18} />
            <select 
              value={i18n.language}
              onChange={(e) => i18n.changeLanguage(e.target.value)}
              style={{
                background: 'transparent',
                border: 'none',
                color: 'var(--text-primary)',
                fontWeight: '500',
                outline: 'none',
                cursor: 'pointer'
              }}
            >
              <option value="en" style={{color: 'black'}}>English</option>
              <option value="kn" style={{color: 'black'}}>ಕನ್ನಡ</option>
              <option value="hi" style={{color: 'black'}}>हिन्दी</option>
            </select>
          </div>
        </div>
      </header>

      <nav className="portal-tabs scrollable-tabs">
        <button className={activeTab === 'overview' ? 'active' : ''} onClick={() => setActiveTab('overview')}>
          <TrendingUp size={18} /> Overview
        </button>
        <button className={activeTab === 'academics' ? 'active' : ''} onClick={() => setActiveTab('academics')}>
          <BookOpen size={18} /> Academics
        </button>
        <button className={activeTab === 'campus' ? 'active' : ''} onClick={() => setActiveTab('campus')}>
          <CalendarDays size={18} /> Campus
        </button>
        <button className={activeTab === 'admin' ? 'active' : ''} onClick={() => setActiveTab('admin')}>
          <ShieldCheck size={18} /> Admin
        </button>
        <button className={activeTab === 'profile' ? 'active' : ''} onClick={() => setActiveTab('profile')}>
          <User size={18} /> Profile
        </button>
      </nav>

      <div className="tab-content">
        {activeTab === 'overview' && (
          <div className="portal-grid">
            {/* Attendance & Heatmap (Condensed) */}
            <div className="glass-card attendance-summary-card">
              <div className="card-header">
                <h3>Attendance Summary</h3>
                <TrendingUp size={20} />
              </div>
              <div className="summary-flex">
                <div className="circular-mini">
                   <svg viewBox="0 0 36 36" className="circular-chart-mini">
                    <path className="circle-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <path className="circle" strokeDasharray={`${data?.attendance?.percentage || 0}, 100`} d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
                    <text x="18" y="20.35" className="percentage-mini">{data?.attendance?.percentage || 0}%</text>
                  </svg>
                </div>
                <div className="quick-stats">
                  <span><strong>{data?.attendance?.present}</strong> Present</span>
                  <span><strong>{data?.attendance?.total}</strong> Total</span>
                </div>
              </div>
            </div>

            <div className="glass-card announcement-preview-card">
              <div className="card-header">
                <h3>Latest Notices</h3>
                <Megaphone size={20} />
              </div>
              <div className="preview-list">
                {portalData.announcements.slice(0, 2).map(ann => (
                  <div key={ann.id} className="preview-item">
                    <div className={`priority-line ${ann.priority.toLowerCase()}`}></div>
                    <div>
                      <strong>{ann.title}</strong>
                      <small>{ann.date} • {ann.category}</small>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-card heatmap-card full-width">
              <div className="card-header">
                <h3>Attendance Density</h3>
                <Calendar size={20} />
              </div>
              <HeatmapCalendar data={heatmapData} />
            </div>

            <div className="glass-card achievements-mini">
              <div className="card-header">
                <h3>Streaks & Badges</h3>
                <Flame size={20} className="icon-streak" />
              </div>
              <div className="streak-viz">
                <div className="streak-count">{data?.gamification?.streakCount || 0}</div>
                <p>Days active this month!</p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'academics' && (
          <div className="portal-grid">
             {/* Assignments & Projects */}
             <div className="glass-card assignments-card full-width">
              <div className="card-header">
                <h3>Assignments & Project Tracking</h3>
                <ListTodo size={20} />
              </div>
              <div className="academics-sub-grid">
                <div className="assignment-list-container">
                  <h5>Assignments</h5>
                  <div className="task-list">
                    {portalData.assignments.map(task => (
                      <div key={task.id} className="task-item">
                        <div className="task-check">
                          {task.status === 'Submitted' ? <CheckCircle size={20} className="success" /> : <Clock size={20} className="pending" />}
                        </div>
                        <div className="task-info">
                          <strong>{task.title}</strong>
                          <span>{task.course} • Due: {task.due}</span>
                        </div>
                        <span className={`priority-tag ${task.priority.toLowerCase()}`}>{task.priority}</span>
                      </div>
                    ))}
                  </div>
                </div>
                <div className="project-list-container">
                  <h5>Ongoing Projects</h5>
                  <div className="project-cards">
                    {portalData.projects.map(proj => (
                      <div key={proj.id} className="project-mini-card">
                        <div className="proj-header">
                          <strong>{proj.name}</strong>
                          <span className="phase-tag">{proj.phase}</span>
                        </div>
                        <div className="progress-bar-container">
                          <div className="progress-bar" style={{ width: `${proj.progress}%` }}></div>
                        </div>
                        <div className="proj-footer">
                          <span>Progress: {proj.progress}%</span>
                          <span>Team: {proj.team}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Labs & Practical Reports */}
            <div className="glass-card labs-card">
              <div className="card-header">
                <h3>Lab Reports & Submissions</h3>
                <FlaskConical size={20} />
              </div>
              <div className="lab-list">
                {portalData.labs.map(lab => (
                  <div key={lab.id} className="lab-item">
                    <div className="lab-info">
                      <strong>{lab.name}</strong>
                      <span>Scheduled: {lab.day}</span>
                    </div>
                    <div className="lab-status">
                      <span className="count">{lab.reports} Done</span>
                      {lab.pending > 0 && <span className="pending-tag">{lab.pending} Pending</span>}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Exams & Results (Existing but condensed) */}
            <div className="glass-card exam-results-combo">
               <div className="card-header">
                <h3>Exams & Results</h3>
                <FileText size={20} />
              </div>
              <div className="tabs-mini">
                <table className="mini-table">
                  <thead><tr><th>Subject</th><th>Status/Grade</th></tr></thead>
                  <tbody>
                    {portalData.exams.slice(0, 2).map(e => (
                      <tr key={e.id}><td>{e.subject}</td><td><span className="status-tag upcoming">20 May</span></td></tr>
                    ))}
                    {portalData.results.slice(0, 2).map((r, i) => (
                      <tr key={i}><td>{r.subject}</td><td><span className="grade-tag high">{r.grade}</span></td></tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Syllabus Detail (Existing) */}
            <div className="glass-card courses-card full-width">
              <div className="card-header">
                <h3>Course Materials & Syllabus</h3>
                <BookOpen size={20} />
              </div>
              <div className="courses-layout">
                {/* Reusing existing logic */}
                <div className="courses-list">
                  {portalData.courses.map(course => (
                    <div key={course.id} className={`course-nav-item ${selectedCourse?.id === course.id ? 'active' : ''}`} onClick={() => setSelectedCourse(course)}>
                      <div className="course-code">{course.id}</div>
                      <div className="course-name-mini">{course.name}</div>
                      <ChevronRight size={16} />
                    </div>
                  ))}
                </div>
                <div className="course-detail-view">
                   {selectedCourse ? (
                    <div className="course-detail-content">
                      <h4>{selectedCourse.name}</h4>
                      <p className="instructor">Instructor: {selectedCourse.instructor}</p>
                      <section>
                        <h5>Syllabus Overview</h5>
                        <p>{selectedCourse.syllabus}</p>
                      </section>
                      <section>
                        <h5>Resources</h5>
                        <div className="notes-list">
                          {selectedCourse.notes.map((note, i) => (
                            <div key={i} className="note-item">
                              <div className="note-info"><FileText size={16} /><span>{note.title}</span></div>
                              <button className="btn-icon"><Download size={16} /></button>
                            </div>
                          ))}
                        </div>
                      </section>
                    </div>
                  ) : <div className="no-selection"><p>Select a course to view details</p></div>}
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'campus' && (
          <div className="portal-grid">
            <div className="glass-card calendar-card full-width">
              <div className="card-header">
                <h3>Campus Events & Holidays</h3>
                <CalendarDays size={20} />
              </div>
              <CampusCalendar events={portalData.events} />
            </div>

            <div className="glass-card announcements-card full-width">
              <div className="card-header">
                <h3>Official Announcements & Circulars</h3>
                <Megaphone size={20} />
              </div>
              <div className="announcement-grid">
                {portalData.announcements.map(ann => (
                  <div key={ann.id} className="announcement-card-item">
                    <div className={`ann-tag ${ann.priority.toLowerCase()}`}>{ann.priority}</div>
                    <h4>{ann.title}</h4>
                    <p>Released on {ann.date} • {ann.category}</p>
                    <button className="btn-text">Read Full Circular <ExternalLink size={14} /></button>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-card faculty-card full-width">
              <div className="card-header">
                <h3>Faculty Directory</h3>
                <Users size={20} />
              </div>
              <div className="search-bar">
                <Search size={18} />
                <input type="text" placeholder="Search by name or department..." value={facultySearch} onChange={e => setFacultySearch(e.target.value)} />
              </div>
              <div className="faculty-grid">
                {filteredFaculty.map((fac, i) => (
                  <div key={i} className="faculty-item">
                    <div className="fac-avatar">{fac.image}</div>
                    <div className="fac-info">
                      <strong>{fac.name}</strong>
                      <span>{fac.role} • {fac.dept}</span>
                      <div className="fac-contacts">
                        <Mail size={14} /> <span>{fac.email}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="glass-card complaint-card full-width">
              <div className="card-header">
                <h3>Grievance & Support</h3>
                <MessageSquare size={20} />
              </div>
              <div className="grievance-flex">
                 <div className="grievance-info">
                    <p>Submit your concerns regarding campus life, infrastructure, or academic hurdles.</p>
                    <button className="btn-primary" onClick={() => { setDisputeForm({...disputeForm, type: 'complaint'}); setShowDisputeModal(true); }}>
                      Raise New Grievance
                    </button>
                 </div>
                 <div className="grievance-status-pills">
                    <div className="g-pill"><span>Open</span><strong>0</strong></div>
                    <div className="g-pill"><span>Pending</span><strong>1</strong></div>
                    <div className="g-pill"><span>Resolved</span><strong>12</strong></div>
                 </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'admin' && (
          <div className="portal-grid">
            <div className="glass-card fee-card">
              <div className="card-header">
                <h3>Fee Management</h3>
                <CreditCard size={20} />
              </div>
              <div className="fee-status">
                 <div className="fee-main">
                    <span>Outstanding Balance</span>
                    <h2>₹{portalData.fees.due.toLocaleString()}</h2>
                 </div>
                 <button className="btn-primary full-width">Pay Outstanding Fee</button>
              </div>
              <div className="fee-history">
                 <h5>Payment History</h5>
                 {portalData.fees.history.map((txn, i) => (
                    <div key={i} className="txn-item">
                       <div className="txn-info">
                          <strong>₹{txn.amount.toLocaleString()}</strong>
                          <span>{txn.date} • {txn.id}</span>
                       </div>
                       <button className="btn-icon"><Download size={16} /></button>
                    </div>
                 ))}
              </div>
            </div>

            <div className="glass-card library-card">
              <div className="card-header">
                <h3>Library & Digital Card</h3>
                <BookMarked size={20} />
              </div>
              <div className="lib-card-viz">
                 <div className="lib-header">COLLEGE LIBRARY</div>
                 <div className="lib-body">
                    <div className="lib-qr">QR</div>
                    <div className="lib-details">
                       <strong>{data?.student?.name}</strong>
                       <span>{portalData.library.cardNo}</span>
                    </div>
                 </div>
              </div>
              <div className="borrowed-books">
                 <h5>Current Loans</h5>
                 {portalData.library.booksBorrowed.map((book, i) => (
                    <div key={i} className={`book-item ${book.status.toLowerCase()}`}>
                       <span>{book.title}</span>
                       <small>Due: {book.due}</small>
                    </div>
                 ))}
                 {portalData.library.fine > 0 && <div className="lib-fine">Pending Fine: ₹{portalData.library.fine}</div>}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'profile' && (
          <div className="portal-grid">
            <div className="glass-card id-card-full">
              <div className="card-header">
                <h3>Student ID & Identity</h3>
                <Badge size={20} />
              </div>
              <div className="id-card-content">
                 <div className="id-photo"><GraduationCap size={48} /></div>
                 <div className="id-fields">
                    <div className="field"><span>USN</span><strong>{data?.student?.usn}</strong></div>
                    <div className="field"><span>Branch</span><strong>{data?.student?.branch}</strong></div>
                    <div className="field"><span>Batch</span><strong>2022-2026</strong></div>
                    <div className="field"><span>Blood Group</span><strong>O+</strong></div>
                 </div>
              </div>
            </div>

            <div className="glass-card personal-info-card">
              <div className="card-header">
                <h3>Personal & Family Information</h3>
                <Home size={20} />
              </div>
              <div className="profile-sections">
                 <div className="p-sec">
                    <h5>Contact Details</h5>
                    <p><Mail size={14}/> {portalData.profile.personal.email}</p>
                    <p><Phone size={14}/> {portalData.profile.personal.phone}</p>
                    <p><Home size={14}/> {portalData.profile.personal.address}</p>
                 </div>
                 <div className="p-sec">
                    <h5>Family Details</h5>
                    <p>Father: {portalData.profile.family.father}</p>
                    <p>Mother: {portalData.profile.family.mother}</p>
                    <p>Emergency: {portalData.profile.family.emergency}</p>
                 </div>
              </div>
            </div>

            <div className="glass-card documents-card">
              <div className="card-header">
                <h3>Document Vault</h3>
                <Upload size={20} />
              </div>
              <div className="doc-list">
                 {portalData.profile.documents.map((doc, i) => (
                    <div key={i} className="doc-item">
                       <div className="doc-info">
                          <Paperclip size={16} />
                          <strong>{doc.name}</strong>
                          <small>{doc.size} • {doc.type}</small>
                       </div>
                       <button className="btn-icon"><Download size={16} /></button>
                    </div>
                 ))}
                 <button className="btn-secondary full-width mt-1"><Upload size={16} /> Upload New Document</button>
              </div>
            </div>

            <div className="glass-card settings-card">
              <div className="card-header">
                <h3>Account Settings</h3>
                <Settings size={20} />
              </div>
              <div className="settings-options">
                 <button className="btn-setting"><span>Change Password</span> <ChevronRight size={16}/></button>
                 <button className="btn-setting"><span>Two-Factor Authentication</span> <span className="status-off">Off</span></button>
                 <button className="btn-setting"><span>Notification Preferences</span> <ChevronRight size={16}/></button>
                 <button className="btn-setting danger"><span>Deactivate Portal Access</span></button>
              </div>
            </div>
          </div>
        )}
      </div>

      {showDisputeModal && (
        <div className="modal-overlay">
          <div className="glass-panel modal-content">
            <h2>{disputeForm.type === 'attendance' ? 'Raise Attendance Dispute' : 'Submit Grievance'}</h2>
            <form onSubmit={handleDisputeSubmit}>
              <div className="form-group">
                <label>{disputeForm.type === 'attendance' ? 'Subject' : 'Category'}</label>
                <input type="text" required value={disputeForm.subject} onChange={e => setDisputeForm({...disputeForm, subject: e.target.value})} />
              </div>
              <div className="form-group">
                <label>Details</label>
                <textarea required value={disputeForm.reason} onChange={e => setDisputeForm({...disputeForm, reason: e.target.value})} />
              </div>
              <div className="modal-actions">
                <button type="button" onClick={() => setShowDisputeModal(false)}>Cancel</button>
                <button type="submit" className="btn-primary">Submit</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentPortal;
