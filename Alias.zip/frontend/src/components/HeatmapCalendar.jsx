import React from 'react';
import './HeatmapCalendar.css';

const HeatmapCalendar = ({ data = [] }) => {
  // Mock data generation if none provided
  const generateMockData = () => {
    const today = new Date();
    const mock = [];
    for (let i = 0; i < 180; i++) {
      const d = new Date();
      d.setDate(today.getDate() - i);
      mock.push({
        date: d.toISOString().split('T')[0],
        count: Math.floor(Math.random() * 5) // 0 to 4 classes per day
      });
    }
    return mock;
  };

  const displayData = data.length > 0 ? data : generateMockData();

  // Group by week
  const weeks = [];
  let currentWeek = [];
  
  // We need to align with days of week
  const startDate = new Date(displayData[displayData.length - 1].date);
  const startDay = startDate.getDay(); // 0 is Sunday
  
  // Padding for the first week
  for (let i = 0; i < startDay; i++) {
    currentWeek.push(null);
  }

  [...displayData].reverse().forEach((day, index) => {
    currentWeek.push(day);
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
  });
  if (currentWeek.length > 0) weeks.push(currentWeek);

  const getIntensity = (count) => {
    if (!count) return 'level-0';
    if (count === 1) return 'level-1';
    if (count === 2) return 'level-2';
    if (count === 3) return 'level-3';
    return 'level-4';
  };

  return (
    <div className="heatmap-container">
      <div className="heatmap-labels">
        <span>Mon</span>
        <span>Wed</span>
        <span>Fri</span>
      </div>
      <div className="heatmap-grid">
        {weeks.map((week, weekIdx) => (
          <div key={weekIdx} className="heatmap-column">
            {week.map((day, dayIdx) => (
              <div 
                key={dayIdx} 
                className={`heatmap-cell ${day ? getIntensity(day.count) : 'empty'}`}
                title={day ? `${day.date}: ${day.count} sessions` : ''}
              />
            ))}
          </div>
        ))}
      </div>
      <div className="heatmap-legend">
        <span>Less</span>
        <div className="cell level-0"></div>
        <div className="cell level-1"></div>
        <div className="cell level-2"></div>
        <div className="cell level-3"></div>
        <div className="cell level-4"></div>
        <span>More</span>
      </div>
    </div>
  );
};

export default HeatmapCalendar;
