import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

const resources = {
  en: {
    translation: {
      "dashboard": "Dashboard",
      "attendance": "Attendance",
      "students": "Students",
      "timetable": "Timetable",
      "welcome": "Welcome back",
      "at_risk": "Students at risk",
      "present_today": "Present Today",
      "absent_today": "Absent Today",
      "language": "Language"
    }
  },
  kn: {
    translation: {
      "dashboard": "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
      "attendance": "ಹಾಜರಾತಿ",
      "students": "ವಿದ್ಯಾರ್ಥಿಗಳು",
      "timetable": "ವೇಳಾಪಟ್ಟಿ",
      "welcome": "ಮರಳಿ ಸ್ವಾಗತ",
      "at_risk": "ಅಪಾಯದಲ್ಲಿರುವ ವಿದ್ಯಾರ್ಥಿಗಳು",
      "present_today": "ಇಂದು ಹಾಜರಿದ್ದಾರೆ",
      "absent_today": "ಇಂದು ಗೈರುಹಾಜರಾಗಿದ್ದಾರೆ",
      "language": "ಭಾಷೆ"
    }
  },
  hi: {
    translation: {
      "dashboard": "डैशबोर्ड",
      "attendance": "उपस्थिति",
      "students": "छात्र",
      "timetable": "समय सारिणी",
      "welcome": "वापसी पर स्वागत है",
      "at_risk": "जोखिम वाले छात्र",
      "present_today": "आज उपस्थित",
      "absent_today": "आज अनुपस्थित",
      "language": "भाषा"
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "en",
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
