from motor.motor_asyncio import AsyncIOMotorClient
import os
from dotenv import load_dotenv

load_dotenv()

MONGO_DETAILS = os.getenv("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = os.getenv("DB_NAME", "alias_db")

# tlsInsecure=true is embedded in the URI to work around a pymongo 4.x / Windows
# OpenSSL TLS cipher negotiation issue with MongoDB Atlas (TLSV1_ALERT_INTERNAL_ERROR).
client = AsyncIOMotorClient(
    MONGO_DETAILS,
    serverSelectionTimeoutMS=5000,
    connectTimeoutMS=5000,
    socketTimeoutMS=5000,
)

database = client[DB_NAME]

student_collection = database.get_collection("students")
teacher_collection = database.get_collection("users")
timetable_collection = database.get_collection("timetable")
attendance_collection = database.get_collection("attendance_logs")
leave_collection = database.get_collection("leaves")
dispute_collection = database.get_collection("disputes")
notification_collection = database.get_collection("notifications")
gamification_collection = database.get_collection("gamification")
audit_collection = database.get_collection("audit_logs")
qr_sessions_collection = database.get_collection("qr_sessions")

# Helper to format object id
def student_helper(student) -> dict:
    return {
        "id": str(student["_id"]),
        "usn": student["usn"],
        "name": student["name"],
        "branch": student["branch"],
        "semester": student["semester"],
        "section": student["section"],
        "parentContact": student.get("parentContact", ""),
        "parentEmail": student.get("parentEmail", ""),
        "enrollmentStatus": student.get("enrollmentStatus", "PENDING"),
        "createdAt": student.get("createdAt")
    }
